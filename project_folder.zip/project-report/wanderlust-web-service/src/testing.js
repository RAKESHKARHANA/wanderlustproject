let today='Abc'.slice(0,1)
console.log(today)